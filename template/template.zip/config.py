# Global Setting for the Database
# PageSize, StartRID, etc..

PageSize = 4096 #bytes
StartRID = 0
ColSize = 8 #bytes
PageRangeHold = 64000 #number of records
RIDCol = 0
IndirectionCol = 1
SchemaCol = 2
TimestampCol = 3
none = 0xFFFFFFFFFFFFFFFF
